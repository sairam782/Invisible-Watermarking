Distribution-Preserving QIM: Trading Noise Margin for Statistical
Undetectability and Scaling Robustness in Invisible Watermarking

Author: Abhishek Sairam Gaduputi (New Jersey Institute of Technology)

Build: pdflatex main.tex && bibtex main && pdflatex main.tex
  && pdflatex main.tex

Primary category: cs.CR (cryptography and security)
Cross-list:       cs.CV (computer vision)

Code: https://github.com/sairam782/Invisible-Watermarking
